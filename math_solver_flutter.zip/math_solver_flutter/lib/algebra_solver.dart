import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AlgebraSolverScreen extends StatefulWidget {
  @override
  _AlgebraSolverScreenState createState() => _AlgebraSolverScreenState();
}

class _AlgebraSolverScreenState extends State<AlgebraSolverScreen> {
  final _controller = TextEditingController();
  String _solution = '';
  late BannerAd _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1299358049837388/6673566975',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Banner ad failed to load: $error');
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _solveEquation() {
    final expr = _controller.text.trim();
    setState(() {
      if (expr.contains('=')) {
        _solution = 'x = 2'; // Placeholder logic
      } else {
        _solution = 'Enter a valid equation (e.g., 2x + 3 = 7)';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Algebra Solver')),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      labelText: 'Enter equation (e.g., 2x + 3 = 7)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _solveEquation,
                    child: Text('Solve'),
                  ),
                  SizedBox(height: 20),
                  Text(
                    _solution,
                    style: TextStyle(fontSize: 18, color: Colors.deepPurple),
                  ),
                ],
              ),
            ),
          ),
          if (_isBannerAdLoaded)
            Container(
              height: _bannerAd.size.height.toDouble(),
              width: _bannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd),
            ),
        ],
      ),
    );
  }
}