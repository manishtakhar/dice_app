import 'package:flutter/material.dart';
import 'home.dart';
import 'calculator.dart';
import 'algebra_solver.dart';
import 'equation_solver.dart';
import 'unit_converter.dart';
import 'area_volume.dart';
import 'graph_plotter.dart';
import 'calculus.dart';
import 'matrix.dart';
import 'statistics_screen.dart';
import 'unlock_timer.dart';

void main() {
  runApp(MathSolverApp());
}

class MathSolverApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Math Solver',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      initialRoute: '/',
      routes: {
        '/': (context) => HomeScreen(),
        '/calculator': (context) => CalculatorScreen(),
        '/algebra': (context) => AlgebraSolverScreen(),
        '/equation': (context) => EquationSolverScreen(),
        '/unit_converter': (context) => UnitConverterScreen(),
        '/area_volume': (context) => AreaVolumeScreen(),
        '/graph': (context) => GraphPlotterScreen(),
        '/calculus': (context) => CalculusScreen(),
        '/matrix': (context) => MatrixScreen(),
        '/statistics': (context) => StatisticsScreen(),
        '/unlock': (context) => UnlockTimerScreen(),
      },
      debugShowCheckedModeBanner: false,
    );
  }
}