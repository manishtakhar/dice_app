import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';

class UnlockTimerScreen extends StatefulWidget {
  @override
  _UnlockTimerScreenState createState() => _UnlockTimerScreenState();
}

class _UnlockTimerScreenState extends State<UnlockTimerScreen> {
  Duration _remaining = Duration.zero;
  Timer? _timer;

  late RewardedAd _rewardedAd;
  bool _isAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadUnlockTime();
    _loadRewardedAd();
  }

  Future<void> _loadUnlockTime() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int? unlockedUntil = prefs.getInt('unlocked_until');

    if (unlockedUntil != null) {
      int now = DateTime.now().millisecondsSinceEpoch;
      if (unlockedUntil > now) {
        _remaining = Duration(milliseconds: unlockedUntil - now);
        _startCountdown();
      }
    }
    setState(() {});
  }

  void _startCountdown() {
    _timer?.cancel();
    _timer = Timer.periodic(Duration(seconds: 1), (_) async {
      final now = DateTime.now().millisecondsSinceEpoch;
      SharedPreferences prefs = await SharedPreferences.getInstance();
      int? unlockedUntil = prefs.getInt('unlocked_until');

      if (unlockedUntil != null && unlockedUntil > now) {
        setState(() {
          _remaining = Duration(milliseconds: unlockedUntil - now);
        });
      } else {
        setState(() => _remaining = Duration.zero);
        _timer?.cancel();
      }
    });
  }

  void _loadRewardedAd() {
    RewardedAd.load(
      adUnitId: 'ca-app-pub-1299358049837388/2442677927',
      request: AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (RewardedAd ad) {
          _rewardedAd = ad;
          _isAdLoaded = true;
          setState(() {});
        },
        onAdFailedToLoad: (error) {
          print('Rewarded ad failed to load: $error');
          _isAdLoaded = false;
        },
      ),
    );
  }

  void _showRewardedAd() {
    if (!_isAdLoaded) return;

    _rewardedAd.show(
      onUserEarnedReward: (ad, reward) async {
        final unlockUntil = DateTime.now()
            .add(Duration(hours: 1))
            .millisecondsSinceEpoch;

        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setInt('unlocked_until', unlockUntil);
        _loadUnlockTime();
        _loadRewardedAd();
      },
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    if (_isAdLoaded) _rewardedAd.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    String formatted = _remaining.inSeconds > 0
        ? '${_remaining.inMinutes.remainder(60)}m ${_remaining.inSeconds.remainder(60)}s remaining'
        : 'Access locked';

    return Scaffold(
      appBar: AppBar(title: Text('Feature Access Timer')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              formatted,
              style: TextStyle(fontSize: 20, color: Colors.deepPurple),
            ),
            SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _isAdLoaded ? _showRewardedAd : null,
              icon: Icon(Icons.lock_open),
              label: Text('Unlock for 1 Hour (Watch Ad)'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.deepPurple,
              ),
            ),
          ],
        ),
      ),
    );
  }
}