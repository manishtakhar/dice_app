import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:fl_chart/fl_chart.dart';

class GraphPlotterScreen extends StatefulWidget {
  @override
  _GraphPlotterScreenState createState() => _GraphPlotterScreenState();
}

class _GraphPlotterScreenState extends State<GraphPlotterScreen> {
  final _controller = TextEditingController();
  List<FlSpot> _points = [];
  late BannerAd _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1299358049837388/6673566975',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Banner ad failed: $error');
        },
      ),
    )..load();
  }

  void _plotFunction() {
    final func = _controller.text.trim().toLowerCase();
    List<FlSpot> temp = [];

    try {
      for (double x = -10; x <= 10; x += 0.5) {
        double y;
        if (func == 'x^2') {
          y = x * x;
        } else if (func == 'sin(x)') {
          y = 10 * (x / 10).sin();
        } else if (func == 'x') {
          y = x;
        } else {
          y = 0;
        }
        temp.add(FlSpot(x, y));
      }
      setState(() => _points = temp);
    } catch (e) {
      setState(() => _points = []);
    }
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Graph Plotter')),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      labelText: 'Enter function (e.g. x^2, x, sin(x))',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: _plotFunction,
                    child: Text('Plot'),
                  ),
                  SizedBox(height: 10),
                  Expanded(
                    child: _points.isEmpty
                        ? Center(child: Text('No data to display'))
                        : LineChart(
                            LineChartData(
                              minX: -10,
                              maxX: 10,
                              minY: -10,
                              maxY: 100,
                              titlesData: FlTitlesData(show: false),
                              lineBarsData: [
                                LineChartBarData(
                                  spots: _points,
                                  isCurved: true,
                                  colors: [Colors.deepPurple],
                                  barWidth: 3,
                                )
                              ],
                            ),
                          ),
                  ),
                ],
              ),
            ),
          ),
          if (_isBannerAdLoaded)
            Container(
              height: _bannerAd.size.height.toDouble(),
              width: _bannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd),
            ),
        ],
      ),
    );
  }
}