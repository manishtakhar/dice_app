import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class UnitConverterScreen extends StatefulWidget {
  @override
  _UnitConverterScreenState createState() => _UnitConverterScreenState();
}

class _UnitConverterScreenState extends State<UnitConverterScreen>
    with SingleTickerProviderStateMixin {
  final _valueController = TextEditingController();
  String _convertedValue = '';
  TabController? _tabController;

  late BannerAd _bannerAd;
  bool _isBannerAdLoaded = false;

  final units = {
    'Length': {'m': 1.0, 'cm': 100.0, 'km': 0.001},
    'Weight': {'kg': 1.0, 'g': 1000.0, 'mg': 1e6},
    'Time': {'s': 1.0, 'min': 1 / 60, 'hr': 1 / 3600},
  };

  String _fromUnit = 'm';
  String _toUnit = 'cm';
  String _category = 'Length';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: units.keys.length, vsync: this);
    _tabController!.addListener(() {
      setState(() {
        _category = units.keys.elementAt(_tabController!.index);
        _fromUnit = units[_category]!.keys.first;
        _toUnit = units[_category]!.keys.last;
      });
    });

    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1299358049837388/6673566975',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Banner ad failed to load: $error');
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    _tabController?.dispose();
    _valueController.dispose();
    super.dispose();
  }

  void _convert() {
    final input = double.tryParse(_valueController.text.trim());
    if (input == null) {
      setState(() => _convertedValue = 'Invalid input');
      return;
    }
    final fromFactor = units[_category]![_fromUnit]!;
    final toFactor = units[_category]![_toUnit]!;
    final result = input * (toFactor / fromFactor);
    setState(() => _convertedValue = result.toStringAsFixed(4));
  }

  @override
  Widget build(BuildContext context) {
    final unitList = units[_category]!.keys.toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Unit Converter'),
        bottom: TabBar(
          controller: _tabController,
          tabs: units.keys.map((e) => Tab(text: e)).toList(),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: units.keys.map((_) {
                return Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: [
                      TextField(
                        controller: _valueController,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Enter value',
                          border: OutlineInputBorder(),
                        ),
                      ),
                      SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          DropdownButton<String>(
                            value: _fromUnit,
                            items: unitList
                                .map((u) =>
                                    DropdownMenuItem(value: u, child: Text(u)))
                                .toList(),
                            onChanged: (v) =>
                                setState(() => _fromUnit = v!),
                          ),
                          Icon(Icons.arrow_forward),
                          DropdownButton<String>(
                            value: _toUnit,
                            items: unitList
                                .map((u) =>
                                    DropdownMenuItem(value: u, child: Text(u)))
                                .toList(),
                            onChanged: (v) => setState(() => _toUnit = v!),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: _convert,
                        child: Text('Convert'),
                      ),
                      SizedBox(height: 20),
                      Text(
                        _convertedValue,
                        style: TextStyle(fontSize: 20, color: Colors.deepPurple),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
          if (_isBannerAdLoaded)
            Container(
              height: _bannerAd.size.height.toDouble(),
              width: _bannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd),
            ),
        ],
      ),
    );
  }
}