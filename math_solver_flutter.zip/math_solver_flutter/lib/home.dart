import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late BannerAd _bannerAd;
  bool _isBannerAdLoaded = false;

  final List<Map<String, dynamic>> _tools = [
    {'title': 'Calculator', 'route': '/calculator', 'icon': Icons.calculate},
    {'title': 'Algebra Solver', 'route': '/algebra', 'icon': Icons.functions},
    {'title': 'Equation Solver', 'route': '/equation', 'icon': Icons.integration_instructions},
    {'title': 'Unit Converter', 'route': '/unit_converter', 'icon': Icons.swap_horiz},
    {'title': 'Area & Volume', 'route': '/area_volume', 'icon': Icons.crop_square},
    {'title': 'Graph Plotter', 'route': '/graph', 'icon': Icons.show_chart},
    {'title': 'Calculus', 'route': '/calculus', 'icon': Icons.timeline},
    {'title': 'Matrix Operations', 'route': '/matrix', 'icon': Icons.grid_on},
    {'title': 'Statistics', 'route': '/statistics', 'icon': Icons.bar_chart},
    {'title': 'Unlock Timer', 'route': '/unlock', 'icon': Icons.lock_open},
  ];

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1299358049837388/6673566975',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Ad failed to load: $error');
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Math Solver - Manish Takhar')),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.all(12),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
              ),
              itemCount: _tools.length,
              itemBuilder: (context, index) {
                final tool = _tools[index];
                return ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple[200],
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  onPressed: () => Navigator.pushNamed(context, tool['route']),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(tool['icon'], size: 36),
                      SizedBox(height: 10),
                      Text(tool['title'], textAlign: TextAlign.center),
                    ],
                  ),
                );
              },
            ),
          ),
          if (_isBannerAdLoaded)
            Container(
              height: _bannerAd.size.height.toDouble(),
              width: _bannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd),
            ),
        ],
      ),
    );
  }
}