import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AreaVolumeScreen extends StatefulWidget {
  @override
  _AreaVolumeScreenState createState() => _AreaVolumeScreenState();
}

class _AreaVolumeScreenState extends State<AreaVolumeScreen> {
  String _shape = 'Rectangle';
  final _controller1 = TextEditingController();
  final _controller2 = TextEditingController();
  String _result = '';

  late BannerAd _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1299358049837388/6673566975',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Banner ad failed: $error');
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    _controller1.dispose();
    _controller2.dispose();
    super.dispose();
  }

  void _calculate() {
    double? val1 = double.tryParse(_controller1.text);
    double? val2 = double.tryParse(_controller2.text);

    if (val1 == null || val2 == null) {
      setState(() => _result = 'Invalid input');
      return;
    }

    double res = 0.0;
    switch (_shape) {
      case 'Rectangle':
        res = val1 * val2;
        setState(() => _result = 'Area = $res');
        break;
      case 'Circle':
        res = 3.1416 * val1 * val1;
        setState(() => _result = 'Area = $res');
        break;
      case 'Cylinder':
        res = 3.1416 * val1 * val1 * val2;
        setState(() => _result = 'Volume = $res');
        break;
      default:
        setState(() => _result = 'Not implemented');
    }
  }

  @override
  Widget build(BuildContext context) {
    List<String> shapes = ['Rectangle', 'Circle', 'Cylinder'];

    return Scaffold(
      appBar: AppBar(title: Text('Area & Volume')),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  DropdownButton<String>(
                    value: _shape,
                    onChanged: (value) => setState(() => _shape = value!),
                    items: shapes
                        .map((s) => DropdownMenuItem(
                              value: s,
                              child: Text(s),
                            ))
                        .toList(),
                  ),
                  TextField(
                    controller: _controller1,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: _shape == 'Circle' ? 'Radius' : 'Length',
                    ),
                  ),
                  SizedBox(height: 8),
                  if (_shape != 'Circle')
                    TextField(
                      controller: _controller2,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: _shape == 'Cylinder' ? 'Height' : 'Width',
                      ),
                    ),
                  SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _calculate,
                    child: Text('Calculate'),
                  ),
                  SizedBox(height: 20),
                  Text(
                    _result,
                    style: TextStyle(fontSize: 18, color: Colors.deepPurple),
                  ),
                ],
              ),
            ),
          ),
          if (_isBannerAdLoaded)
            Container(
              height: _bannerAd.size.height.toDouble(),
              width: _bannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd),
            ),
        ],
      ),
    );
  }
}