import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class CalculusScreen extends StatefulWidget {
  @override
  _CalculusScreenState createState() => _CalculusScreenState();
}

class _CalculusScreenState extends State<CalculusScreen> {
  final _controller = TextEditingController();
  String _result = '';
  String _operation = 'Derivative';

  late BannerAd _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1299358049837388/6673566975',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Banner ad load failed: $error');
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _compute() {
    String expr = _controller.text.trim().toLowerCase();
    setState(() {
      if (_operation == 'Derivative') {
        _result = "d/dx($expr) = 2x"; // Placeholder
      } else if (_operation == 'Integral') {
        _result = "∫$expr dx = x^2 + C"; // Placeholder
      } else {
        _result = 'Invalid operation';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final operations = ['Derivative', 'Integral'];

    return Scaffold(
      appBar: AppBar(title: Text('Calculus Tools')),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  DropdownButton<String>(
                    value: _operation,
                    onChanged: (val) => setState(() => _operation = val!),
                    items: operations
                        .map((op) => DropdownMenuItem(
                              value: op,
                              child: Text(op),
                            ))
                        .toList(),
                  ),
                  TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      labelText: 'Enter function (e.g. x^2)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _compute,
                    child: Text('Compute'),
                  ),
                  SizedBox(height: 20),
                  Text(
                    _result,
                    style: TextStyle(fontSize: 18, color: Colors.deepPurple),
                  ),
                ],
              ),
            ),
          ),
          if (_isBannerAdLoaded)
            Container(
              height: _bannerAd.size.height.toDouble(),
              width: _bannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd),
            ),
        ],
      ),
    );
  }
}