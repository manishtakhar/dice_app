import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:math';

class StatisticsScreen extends StatefulWidget {
  @override
  _StatisticsScreenState createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  final _dataController = TextEditingController();
  String _result = '';

  late BannerAd _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1299358049837388/6673566975',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Banner ad failed: $error');
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    _dataController.dispose();
    super.dispose();
  }

  void _calculateStatistics() {
    final input = _dataController.text.trim();
    final parts = input.split(RegExp(r'[ ,]+'));
    final numbers = parts.map(double.tryParse).where((n) => n != null).cast<double>().toList();

    if (numbers.isEmpty) {
      setState(() => _result = 'Invalid input');
      return;
    }

    final mean = numbers.reduce((a, b) => a + b) / numbers.length;
    final sorted = [...numbers]..sort();
    final mid = sorted.length ~/ 2;
    final median = sorted.length % 2 == 1
        ? sorted[mid]
        : (sorted[mid - 1] + sorted[mid]) / 2;
    final freq = <double, int>{};
    for (final num in numbers) {
      freq[num] = (freq[num] ?? 0) + 1;
    }
    final maxFreq = freq.values.reduce(max);
    final mode = freq.entries
        .where((e) => e.value == maxFreq)
        .map((e) => e.key)
        .toList()
        .join(', ');
    final meanSquare = numbers.map((x) => pow(x - mean, 2)).reduce((a, b) => a + b);
    final stdDev = sqrt(meanSquare / numbers.length);

    setState(() {
      _result = 'Mean: ${mean.toStringAsFixed(2)}\n'
          'Median: ${median.toStringAsFixed(2)}\n'
          'Mode: $mode\n'
          'Std Dev: ${stdDev.toStringAsFixed(2)}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Statistics')),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(
                    controller: _dataController,
                    decoration: InputDecoration(
                      labelText: 'Enter data (e.g. 1, 2, 2, 3)',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.text,
                  ),
                  SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: _calculateStatistics,
                    child: Text('Calculate'),
                  ),
                  SizedBox(height: 16),
                  Text(
                    _result,
                    style: TextStyle(fontSize: 16, color: Colors.deepPurple),
                  ),
                ],
              ),
            ),
          ),
          if (_isBannerAdLoaded)
            Container(
              height: _bannerAd.size.height.toDouble(),
              width: _bannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd),
            ),
        ],
      ),
    );
  }
}