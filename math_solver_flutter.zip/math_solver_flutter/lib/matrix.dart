import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class MatrixScreen extends StatefulWidget {
  @override
  _MatrixScreenState createState() => _MatrixScreenState();
}

class _MatrixScreenState extends State<MatrixScreen> {
  final _matrixAController = TextEditingController();
  final _matrixBController = TextEditingController();
  String _operation = 'Add';
  String _result = '';

  late BannerAd _bannerAd;
  bool _isBannerAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1299358049837388/6673566975',
      size: AdSize.banner,
      request: AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _isBannerAdLoaded = true),
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
          print('Banner ad failed: $error');
        },
      ),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd.dispose();
    _matrixAController.dispose();
    _matrixBController.dispose();
    super.dispose();
  }

  void _performOperation() {
    try {
      List<List<double>> A = _parseMatrix(_matrixAController.text);
      List<List<double>> B = _parseMatrix(_matrixBController.text);

      if (A.isEmpty || B.isEmpty || A.length != B.length || A[0].length != B[0].length) {
        setState(() => _result = 'Matrix size mismatch or invalid input.');
        return;
      }

      List<List<double>> resultMatrix = [];

      if (_operation == 'Add') {
        for (int i = 0; i < A.length; i++) {
          List<double> row = [];
          for (int j = 0; j < A[0].length; j++) {
            row.add(A[i][j] + B[i][j]);
          }
          resultMatrix.add(row);
        }
      } else if (_operation == 'Subtract') {
        for (int i = 0; i < A.length; i++) {
          List<double> row = [];
          for (int j = 0; j < A[0].length; j++) {
            row.add(A[i][j] - B[i][j]);
          }
          resultMatrix.add(row);
        }
      }

      setState(() => _result = _formatMatrix(resultMatrix));
    } catch (e) {
      setState(() => _result = 'Error parsing matrix');
    }
  }

  List<List<double>> _parseMatrix(String input) {
    return input
        .trim()
        .split('\n')
        .map((row) => row.trim().split(RegExp(r'[ ,]+')).map(double.parse).toList())
        .toList();
  }

  String _formatMatrix(List<List<double>> matrix) {
    return matrix.map((row) => row.map((e) => e.toStringAsFixed(2)).join('  ')).join('\n');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Matrix Operations')),
      body: Column(
        children: [
          Expanded(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    DropdownButton<String>(
                      value: _operation,
                      onChanged: (value) => setState(() => _operation = value!),
                      items: ['Add', 'Subtract']
                          .map((op) => DropdownMenuItem(value: op, child: Text(op)))
                          .toList(),
                    ),
                    TextField(
                      controller: _matrixAController,
                      decoration: InputDecoration(
                        labelText: 'Matrix A (e.g. 1 2\\n3 4)',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: _matrixBController,
                      decoration: InputDecoration(
                        labelText: 'Matrix B (same size)',
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: _performOperation,
                      child: Text('Compute'),
                    ),
                    SizedBox(height: 12),
                    Text(
                      _result,
                      style: TextStyle(fontSize: 16, color: Colors.deepPurple),
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (_isBannerAdLoaded)
            Container(
              height: _bannerAd.size.height.toDouble(),
              width: _bannerAd.size.width.toDouble(),
              child: AdWidget(ad: _bannerAd),
            ),
        ],
      ),
    );
  }
}